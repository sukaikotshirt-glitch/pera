// Session timeout variables
let timeoutTimer;
const SESSION_TIMEOUT = 3600000; // 1 hour in milliseconds

// Function to reset the inactivity timer
function resetInactivityTimer() {
    clearTimeout(timeoutTimer);
    timeoutTimer = setTimeout(() => {
        if (firebase.auth().currentUser) {
            firebase.auth().signOut()
                .then(() => {
                    alert('You have been automatically logged out due to inactivity.');
                    window.location.href = 'index.html';
                })
                .catch((error) => {
                    console.error('Auto logout error:', error);
                });
        }
    }, SESSION_TIMEOUT);
}

// Track user activity
function setupActivityListeners() {
    ['mousemove', 'keydown', 'click', 'scroll'].forEach(event => {
        document.addEventListener(event, resetInactivityTimer);
    });
    resetInactivityTimer();
}

// Toggle password visibility
function setupPasswordToggle() {
    const toggleBtn = document.querySelector('.toggle-password');
    const passwordField = document.getElementById('password');
    
    if (toggleBtn && passwordField) {
        toggleBtn.addEventListener('click', () => {
            if (passwordField.type === 'password') {
                passwordField.type = 'text';
                toggleBtn.textContent = '👁️';
            } else {
                passwordField.type = 'password';
                toggleBtn.textContent = '👁️';
            }
        });
    }
}

// Firebase Auth State Listener
firebase.auth().onAuthStateChanged((user) => {
    if (user) {
        if (window.location.pathname.includes('index.html')) {
            window.location.href = 'dashboard.html';
        }
        setupActivityListeners();
    } else {
        if (!window.location.pathname.includes('index.html')) {
            window.location.href = 'index.html';
        }
        clearTimeout(timeoutTimer);
    }
});

// Login form handling
document.addEventListener('DOMContentLoaded', () => {
    setupPasswordToggle();
    
    const loginForm = document.querySelector('.login-form');
    if (loginForm) {
        loginForm.addEventListener('submit', (e) => {
            e.preventDefault();
            
            let userInput = document.getElementById('username').value.trim();
            const password = document.getElementById('password').value;
            
            // Auto-append @pvvnl.com if user entered just a 10-digit number
            let email = /^\d{10}$/.test(userInput) ? userInput + '@pvvnl.com' : userInput;
            
            firebase.auth().signInWithEmailAndPassword(email, password)
                .then(() => {
                    window.location.href = 'dashboard.html';
                })
                .catch((error) => {
                    console.error('Login error:', error);
                    let customMessage = 'Login failed. Please try again.';
                    switch (error.code) {
                        case 'auth/invalid-email':
                            customMessage = 'Invalid User ID format. Please enter your 10-digit number.';
                            break;
                        case 'auth/user-disabled':
                            customMessage = 'This user account has been disabled.';
                            break;
                        case 'auth/user-not-found':
                            customMessage = 'No account found with this User ID.';
                            break;
                        case 'auth/wrong-password':
                            customMessage = 'Incorrect password. Please try again.';
                            break;
                    }
                    alert(customMessage);
                });
        });
    }
});

// Logout functionality (for other pages)
const logoutBtn = document.getElementById('logoutBtn');
if (logoutBtn) {
    logoutBtn.addEventListener('click', (e) => {
        e.preventDefault();
        firebase.auth().signOut()
            .then(() => {
                window.location.href = 'index.html';
            })
            .catch((error) => {
                console.error('Logout error:', error);
                alert("Error during logout: " + error.message);
            });
    });
}